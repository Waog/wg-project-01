package de.lessvoid.nifty.controls.scrollpanel.builder;

import de.lessvoid.nifty.builder.ControlBuilder;

public class ScrollPanelBuilder extends ControlBuilder {
  public ScrollPanelBuilder(final String id) {
    super(id, "scrollPanel");
  }
}
