package de.lessvoid.nifty.controls.textfield;

public interface TextFieldView {

  void textChangeEvent(String newText);

}
