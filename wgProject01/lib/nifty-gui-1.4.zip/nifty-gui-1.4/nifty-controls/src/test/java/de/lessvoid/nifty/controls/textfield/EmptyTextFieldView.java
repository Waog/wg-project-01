package de.lessvoid.nifty.controls.textfield;


public class EmptyTextFieldView implements TextFieldView {

  @Override
  public void textChangeEvent(final String newText) {
  }

}
