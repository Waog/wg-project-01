package de.lessvoid.nifty;

public interface Parameterizable {
	void setParameters(String parameters);
}
