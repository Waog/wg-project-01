package de.lessvoid.nifty.render;

public enum BlendMode {
  BLEND,
  MULIPLY
}
