package de.lessvoid.nifty;

/**
 * Marker interface for NiftyEvents.
 * @author void
 */
public interface NiftyEvent {
}
