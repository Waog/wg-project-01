package de.lessvoid.nifty;

public interface NiftyDelayedMethodInvoke {
  void performInvoke(Object ... invokeParametersParam);
}
